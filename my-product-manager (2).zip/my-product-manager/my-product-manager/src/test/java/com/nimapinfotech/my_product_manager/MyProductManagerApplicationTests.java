package com.nimapinfotech.my_product_manager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyProductManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
